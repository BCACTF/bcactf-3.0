#!/bin/bash
echo $1
source $1
