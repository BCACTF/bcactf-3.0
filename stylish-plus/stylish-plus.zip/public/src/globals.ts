import lib from 'micromodal';

declare global {
    const MicroModal: typeof lib;
}

export {};