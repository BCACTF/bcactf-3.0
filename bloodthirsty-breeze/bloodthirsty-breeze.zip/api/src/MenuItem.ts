export interface MenuItem {
    name: string;
    description: string;
    price: string;
    imageURL?: string;
}